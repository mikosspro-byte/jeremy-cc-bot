import express from 'express';
import User from '../models/User.js';
import Order from '../models/Order.js';
import GiftCard from '../models/GiftCard.js';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

// Middleware pour vérifier le contexte Telegram
function verifyTelegramContext(req, res, next) {
  const initData = req.headers['x-telegram-init-data'] || '';
  if (!initData) {
    return res.status(401).json({ error: 'Non autorisé : contexte Telegram manquant' });
  }
  // En production, valider la signature initData avec le bot token
  req.telegramId = req.headers['x-telegram-id'] || '';
  next();
}

// === GET /api/balance ===
router.get('/balance', verifyTelegramContext, async (req, res) => {
  try {
    const user = await User.findOne({ telegramId: req.telegramId });
    if (!user) {
      // Créer un nouvel utilisateur
      const newUser = new User({
        telegramId: req.telegramId,
        username: req.headers['x-telegram-username'] || '',
        firstName: req.headers['x-telegram-first-name'] || ''
      });
      await newUser.save();
      return res.json({ balance: 0, userId: newUser._id });
    }
    res.json({ balance: user.balance, userId: user._id });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === POST /api/order ===
router.post('/order', verifyTelegramContext, async (req, res) => {
  try {
    const { items, total } = req.body;
    
    // Valider les données
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Panier vide' });
    }
    
    if (typeof total !== 'number' || total <= 0) {
      return res.status(400).json({ error: 'Montant invalide' });
    }

    // Vérifier que les codes sont disponibles
    for (const item of items) {
      const available = await GiftCard.countDocuments({
        brand: item.brand,
        amount: item.amount,
        status: 'available'
      });
      if (available < item.qty) {
        return res.status(409).json({
          error: `Pas assez de cartes ${item.brand} ${item.amount}€ en stock (disponible: ${available}, demandé: ${item.qty})`
        });
      }
    }

    // Créer la commande
    const orderId = uuidv4().slice(0, 8).toUpperCase();
    const order = new Order({
      orderId,
      telegramId: req.telegramId,
      items,
      total,
      status: 'pending'
    });
    await order.save();

    // Mettre à jour l'utilisateur
    await User.findOneAndUpdate(
      { telegramId: req.telegramId },
      {
        $inc: { orderCount: 1, totalSpent: total },
        lastActivity: new Date()
      },
      { upsert: true }
    );

    res.status(201).json({
      success: true,
      orderId,
      message: 'Commande créée. Nos équipes vont vous contacter pour le paiement.',
      total
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === GET /api/orders ===
router.get('/orders', verifyTelegramContext, async (req, res) => {
  try {
    const orders = await Order.find({ telegramId: req.telegramId })
      .sort({ createdAt: -1 })
      .limit(20);
    res.json({ orders });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === GET /api/order/:orderId ===
router.get('/order/:orderId', verifyTelegramContext, async (req, res) => {
  try {
    const order = await Order.findOne({
      orderId: req.params.orderId,
      telegramId: req.telegramId
    });
    if (!order) {
      return res.status(404).json({ error: 'Commande non trouvée' });
    }
    res.json({ order });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === GET /api/stock ===
router.get('/stock', async (req, res) => {
  try {
    const cards = await GiftCard.aggregate([
      { $match: { status: 'available' } },
      { $group: { _id: '$brand', amounts: { $addToSet: '$amount' }, count: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]);
    res.json({ cards });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
