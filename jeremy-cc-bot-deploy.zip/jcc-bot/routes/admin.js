import express from 'express';
import jwt from 'jsonwebtoken';
import Order from '../models/Order.js';
import GiftCard from '../models/GiftCard.js';
import User from '../models/User.js';
import config from '../config.js';

const router = express.Router();

// Middleware d'authentification admin
function verifyAdminAuth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Token manquant' });
  }

  try {
    const decoded = jwt.verify(token, config.security.jwtSecret);
    if (!decoded.isAdmin) {
      return res.status(403).json({ error: 'Accès refusé' });
    }
    req.admin = decoded;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Token invalide' });
  }
}

// === POST /admin/login ===
router.post('/login', (req, res) => {
  const { password } = req.body;
  
  if (!password || password !== config.security.adminPassword) {
    return res.status(401).json({ error: 'Mot de passe incorrect' });
  }

  const token = jwt.sign({ isAdmin: true }, config.security.jwtSecret, { expiresIn: '7d' });
  res.json({ success: true, token });
});

// === GET /admin/dashboard ===
router.get('/dashboard', verifyAdminAuth, async (req, res) => {
  try {
    const cardsInStock = await GiftCard.countDocuments({ status: 'available' });
    const cardsSold = await GiftCard.countDocuments({ status: 'sold' });
    const totalRevenue = await Order.aggregate([
      { $match: { status: { $in: ['paid', 'codes_sent', 'completed'] } } },
      { $group: { _id: null, total: { $sum: '$total' } } }
    ]);
    const pendingOrders = await Order.countDocuments({ status: 'pending' });
    const totalUsers = await User.countDocuments();

    res.json({
      stats: {
        cardsInStock,
        cardsSold,
        totalRevenue: totalRevenue[0]?.total || 0,
        pendingOrders,
        totalUsers
      }
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === GET /admin/cards ===
router.get('/cards', verifyAdminAuth, async (req, res) => {
  try {
    const page = parseInt(req.query.page || '1');
    const limit = 50;
    const skip = (page - 1) * limit;
    const status = req.query.status || 'available';

    const cards = await GiftCard.find({ status })
      .sort({ addedAt: -1 })
      .skip(skip)
      .limit(limit);
    
    const total = await GiftCard.countDocuments({ status });

    res.json({
      cards,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) }
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === POST /admin/cards/add ===
router.post('/cards/add', verifyAdminAuth, async (req, res) => {
  try {
    const { brand, amount, codes, costPrice } = req.body;

    if (!brand || !amount || !codes || !Array.isArray(codes) || !costPrice) {
      return res.status(400).json({ error: 'Données manquantes' });
    }

    const cards = codes.map(code => ({
      brand,
      amount,
      code,
      costPrice,
      sellPrice: amount, // Prix de vente = montant de la carte
      status: 'available'
    }));

    const result = await GiftCard.insertMany(cards);
    res.status(201).json({ success: true, count: result.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === POST /admin/orders/:orderId/send-codes ===
router.post('/orders/:orderId/send-codes', verifyAdminAuth, async (req, res) => {
  try {
    const { orderId } = req.params;
    const { codes } = req.body;

    const order = await Order.findOne({ orderId });
    if (!order) {
      return res.status(404).json({ error: 'Commande non trouvée' });
    }

    // Mettre à jour la commande
    order.codes = codes;
    order.status = 'codes_sent';
    await order.save();

    // Marquer les cartes comme vendues
    await GiftCard.updateMany(
      { code: { $in: codes } },
      { status: 'sold', purchasedBy: order.telegramId, purchasedAt: new Date() }
    );

    res.json({ success: true, message: 'Codes envoyés' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === GET /admin/orders ===
router.get('/orders', verifyAdminAuth, async (req, res) => {
  try {
    const page = parseInt(req.query.page || '1');
    const limit = 50;
    const skip = (page - 1) * limit;
    const status = req.query.status || 'pending';

    const orders = await Order.find({ status })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);
    
    const total = await Order.countDocuments({ status });

    res.json({
      orders,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) }
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === POST /admin/orders/:orderId/status ===
router.post('/orders/:orderId/status', verifyAdminAuth, async (req, res) => {
  try {
    const { orderId } = req.params;
    const { status } = req.body;

    const validStatuses = ['pending', 'paid', 'codes_sent', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Statut invalide' });
    }

    const order = await Order.findOneAndUpdate(
      { orderId },
      { status },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({ error: 'Commande non trouvée' });
    }

    res.json({ success: true, order });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// === GET /admin/stats ===
router.get('/stats', verifyAdminAuth, async (req, res) => {
  try {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.setDate(now.getDate() - 30));

    const totalRevenue = await Order.aggregate([
      { $group: { _id: null, total: { $sum: '$total' } } }
    ]);

    const revenueThisMonth = await Order.aggregate([
      { $match: { createdAt: { $gte: thirtyDaysAgo } } },
      { $group: { _id: null, total: { $sum: '$total' } } }
    ]);

    const revenueByBrand = await Order.aggregate([
      { $unwind: '$items' },
      { $group: {
          _id: '$items.brand',
          count: { $sum: '$items.quantity' },
          revenue: { $sum: { $multiply: ['$items.quantity', '$items.unitPrice'] } }
        }
      },
      { $sort: { revenue: -1 } }
    ]);

    res.json({
      totalRevenue: totalRevenue[0]?.total || 0,
      revenueThisMonth: revenueThisMonth[0]?.total || 0,
      revenueByBrand
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
