import mongoose from 'mongoose';

const giftCardSchema = new mongoose.Schema({
  brand: { type: String, required: true, index: true },
  amount: { type: Number, required: true },
  code: { type: String, unique: true, sparse: true },
  pin: String,
  status: {
    type: String,
    enum: ['available', 'sold', 'expired'],
    default: 'available',
    index: true
  },
  costPrice: { type: Number, required: true },
  sellPrice: { type: Number, required: true },
  purchasedBy: String, // telegramId de l'acheteur
  purchasedAt: Date,
  notes: String,
  addedAt: { type: Date, default: Date.now, index: true },
  expiresAt: Date
}, { timestamps: true });

export default mongoose.model('GiftCard', giftCardSchema);
