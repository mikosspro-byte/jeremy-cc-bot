import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  orderId: { type: String, unique: true, required: true, index: true },
  telegramId: { type: String, required: true, index: true },
  items: [{
    brand: String,
    amount: Number,
    quantity: Number,
    unitPrice: Number
  }],
  total: { type: Number, required: true },
  status: {
    type: String,
    enum: ['pending', 'paid', 'codes_sent', 'completed', 'cancelled'],
    default: 'pending'
  },
  paymentMethod: { type: String, default: 'manual' },
  codes: [String], // Codes cadeaux fournis
  notes: String,
  createdAt: { type: Date, default: Date.now, index: true },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

export default mongoose.model('Order', orderSchema);
